// =====================================================================
//  1) วางค่า config จาก Firebase Console
//     Project settings → General → Your apps → Web app → SDK setup and configuration → Config
//     (ค่าเหล่านี้เปิดเผยได้ ความปลอดภัยของข้อมูลมาจาก firestore.rules)
// =====================================================================
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// =====================================================================
//  2) ตั้งค่าแอป
// =====================================================================
export const APP_CONFIG = {
  // จำกัดเฉพาะบัญชี Google Workspace ของโดเมนนี้ เช่น "go.buu.ac.th"
  // ปล่อยว่าง "" = อนุญาตทุกบัญชี Google
  // *** ถ้าตั้งค่า ต้องแก้ฟังก์ชัน domainOk() ใน firestore.rules ให้ตรงกันด้วย ***
  allowedDomain: "",

  // จำนวน Senior สูงสุดที่ Junior เลือกได้ (ต้องตรงกับ MAX_PICKS ใน firestore.rules)
  maxPicks: 2,

  // รูปแบบรหัสนิสิต (ต้องตรงกับ regex ใน firestore.rules)
  studentIdPattern: "^[0-9]{8}$"
};
