import { firebaseConfig, APP_CONFIG } from "./firebase-config.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getFirestore, doc, getDoc, setDoc, updateDoc, collection, query, where, onSnapshot,
  runTransaction, writeBatch, serverTimestamp, deleteField, getDocs
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

/* ---------------- helpers ---------------- */
const $ = (id) => document.getElementById(id);
const MAX = APP_CONFIG.maxPicks ?? 2;
const SID_RE = new RegExp(APP_CONFIG.studentIdPattern || "^[0-9]{8}$");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const show = (id, on = true) => $(id).classList.toggle("hidden", !on);
let toastTimer;
function toast(msg, isErr = false) {
  const t = $("toast");
  t.textContent = msg; t.className = "toast" + (isErr ? " error" : "");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.add("hidden"), 3500);
}
function errText(e) {
  const c = e?.code || e?.message || "";
  if (c.includes("permission-denied")) return "ไม่มีสิทธิ์ทำรายการนี้ (permission-denied)";
  if (c.includes("unauthorized-domain")) return "โดเมนนี้ยังไม่ได้เพิ่มใน Firebase Authentication → Authorized domains";
  if (c.includes("popup-blocked")) return "เบราว์เซอร์บล็อกหน้าต่าง Login กรุณาอนุญาต Pop-up";
  if (c.includes("popup-closed-by-user") || c.includes("cancelled-popup-request")) return "ยกเลิกการเข้าสู่ระบบ";
  if (c.includes("unavailable")) return "เชื่อมต่อฐานข้อมูลไม่ได้ กรุณาลองใหม่";
  return e?.message || String(e);
}
function onErr(e) { console.error(e); toast(errText(e), true); }
const avatarHtml = (photo) => (photo ? `<img src="${esc(photo)}" alt="">` : "🌟");
document.querySelectorAll(".maxPicks").forEach((el) => (el.textContent = MAX));

/** Resize & crop an image to a square JPEG data URL (~20-40 KB) so it fits in Firestore without Storage. */
function resizeImage(file, size = 256) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) return reject(new Error("กรุณาเลือกไฟล์รูปภาพ"));
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas"); c.width = c.height = size;
      const s = Math.min(img.width, img.height);
      c.getContext("2d").drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
      URL.revokeObjectURL(img.src);
      resolve(c.toDataURL("image/jpeg", 0.82));
    };
    img.onerror = () => reject(new Error("อ่านรูปภาพไม่ได้"));
    img.src = URL.createObjectURL(file);
  });
}

/* ---------------- config check ---------------- */
if (!firebaseConfig.apiKey || firebaseConfig.apiKey.startsWith("YOUR_")) {
  show("configWarn"); show("loadingView", false);
  throw new Error("Firebase config missing – edit js/firebase-config.js");
}

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();
provider.setCustomParameters(APP_CONFIG.allowedDomain ? { hd: APP_CONFIG.allowedDomain, prompt: "select_account" } : { prompt: "select_account" });
if (APP_CONFIG.allowedDomain) $("loginHint").textContent = `ใช้บัญชี Google ของ @${APP_CONFIG.allowedDomain} เพื่อเข้าสู่ระบบ`;

/* ---------------- state ---------------- */
const S = {
  user: null, profile: null, isAdmin: false, view: null, unsubs: [],
  seniors: {}, myRequest: null, draft: [], dirty: false, clue: null, incoming: [],
  regPhoto: "", spPhoto: "",
  ad: { users: [], requests: [], clues: 0, admins: [] }
};
function clearSubs() { S.unsubs.forEach((u) => u()); S.unsubs = []; }
const SECTIONS = ["loginView", "registerView", "juniorView", "seniorView", "adminView"];

/* ---------------- auth ---------------- */
$("btnGoogle").onclick = async () => {
  $("loginMsg").textContent = "";
  try { await signInWithPopup(auth, provider); } catch (e) { $("loginMsg").textContent = errText(e); }
};
$("btnSignOut").onclick = () => signOut(auth);

onAuthStateChanged(auth, async (user) => {
  clearSubs();
  Object.assign(S, { user: null, profile: null, isAdmin: false, view: null, seniors: {}, myRequest: null, draft: [], dirty: false, clue: null, incoming: [] });
  show("globalError", false);
  SECTIONS.forEach((s) => show(s, false)); show("tabs", false);

  if (!user) { show("userBox", false); show("loadingView", false); show("loginView"); return; }

  const email = (user.email || "").toLowerCase();
  if (APP_CONFIG.allowedDomain && !email.endsWith("@" + APP_CONFIG.allowedDomain.toLowerCase())) {
    await signOut(auth);
    $("loginMsg").textContent = `บัญชี ${email} ไม่ได้รับอนุญาต กรุณาใช้บัญชี @${APP_CONFIG.allowedDomain}`;
    return;
  }

  S.user = user;
  $("userAvatar").src = user.photoURL || "";
  $("userName").textContent = user.displayName || email;
  $("userEmail").textContent = email;
  show("userBox"); show("loadingView");

  try {
    const [adminSnap, profSnap] = await Promise.all([
      getDoc(doc(db, "admins", email)),
      getDoc(doc(db, "users", user.uid))
    ]);
    S.isAdmin = adminSnap.exists();
    S.profile = profSnap.exists() ? profSnap.data() : null;
  } catch (e) {
    show("loadingView", false);
    $("globalError").textContent = "โหลดข้อมูลไม่สำเร็จ: " + errText(e) + " — ตรวจสอบว่า publish firestore.rules แล้ว";
    show("globalError");
    return;
  }
  show("loadingView", false);
  initSession();
});

/* ---------------- session / subscriptions ---------------- */
function initSession() {
  clearSubs();
  const p = S.profile, uid = S.user.uid;

  if (p || S.isAdmin) {
    S.unsubs.push(onSnapshot(collection(db, "seniorProfiles"), (snap) => {
      S.seniors = {}; snap.forEach((d) => (S.seniors[d.id] = d.data()));
      renderJunior(); renderSenior(); renderAdmin();
    }, onErr));
  }
  if (p?.role === "junior") {
    S.unsubs.push(onSnapshot(doc(db, "requests", uid), (snap) => {
      S.myRequest = snap.exists() ? snap.data() : null;
      if (!S.dirty) S.draft = [...(S.myRequest?.selected || [])];
      renderJunior();
    }, onErr));
    getDoc(doc(db, "clues", p.studentId))
      .then((s) => { S.clue = s.exists() ? s.data() : { clues: [] }; renderJunior(); })
      .catch((e) => { S.clue = { clues: [] }; onErr(e); renderJunior(); });
  }
  if (p?.role === "senior") {
    S.unsubs.push(onSnapshot(query(collection(db, "requests"), where("selected", "array-contains", uid)), (snap) => {
      S.incoming = snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((r) => r.submitted);
      renderSenior();
    }, onErr));
    $("spId").value = p.studentId; $("spName").value = p.name;
  }
  if (S.isAdmin) {
    S.unsubs.push(onSnapshot(collection(db, "users"), (s) => { S.ad.users = s.docs.map((d) => d.data()); renderAdmin(); }, onErr));
    S.unsubs.push(onSnapshot(collection(db, "requests"), (s) => { S.ad.requests = s.docs.map((d) => ({ id: d.id, ...d.data() })); renderAdmin(); }, onErr));
    S.unsubs.push(onSnapshot(collection(db, "clues"), (s) => { S.ad.clues = s.size; renderAdmin(); }, onErr));
    S.unsubs.push(onSnapshot(collection(db, "admins"), (s) => { S.ad.admins = s.docs.map((d) => d.id); renderAdmin(); }, onErr));
  }
  buildTabs();
}

function buildTabs() {
  const tabs = [];
  if (!S.profile) tabs.push(["register", "📝 ลงทะเบียน"]);
  if (S.profile?.role === "junior") tabs.push(["junior", "🎓 Junior"]);
  if (S.profile?.role === "senior") tabs.push(["senior", "🌟 Senior"]);
  if (S.isAdmin) tabs.push(["admin", "⚙️ Admin"]);
  if (!tabs.some(([k]) => k === S.view)) S.view = tabs[0][0];
  $("tabs").innerHTML = tabs.map(([k, l]) => `<button class="tab ${k === S.view ? "active" : ""}" data-tab="${k}">${l}</button>`).join("");
  show("tabs", tabs.length > 1);
  SECTIONS.forEach((s) => show(s, s === S.view + "View"));
}
$("tabs").onclick = (e) => { const k = e.target.closest("[data-tab]")?.dataset.tab; if (k) { S.view = k; buildTabs(); } };

/* ---------------- registration ---------------- */
document.querySelectorAll('input[name="role"]').forEach((r) =>
  r.addEventListener("change", () => show("regPhotoBox", document.querySelector('input[name="role"]:checked').value === "senior")));

$("regPhoto").onchange = async (e) => {
  const f = e.target.files?.[0]; if (!f) return;
  try { S.regPhoto = await resizeImage(f); $("regPreview").innerHTML = avatarHtml(S.regPhoto); }
  catch (err) { toast(err.message, true); e.target.value = ""; }
};

$("btnRegister").onclick = async () => {
  const role = document.querySelector('input[name="role"]:checked').value;
  const sid = $("regId").value.trim(), name = $("regName").value.trim();
  const msg = $("regMsg");
  if (!SID_RE.test(sid)) return (msg.textContent = "กรุณากรอกรหัสนิสิตให้ถูกต้อง (8 หลัก)");
  if (!name) return (msg.textContent = "กรุณากรอกชื่อ");
  const roleTh = role === "junior" ? "Junior (น้อง)" : "Senior (พี่)";
  if (!confirm(`ยืนยันลงทะเบียนเป็น ${roleTh}\nรหัสนิสิต ${sid}\nชื่อ ${name}\n\nเปลี่ยนบทบาทภายหลังต้องให้ Admin ดำเนินการ`)) return;

  const uid = S.user.uid, email = S.user.email.toLowerCase();
  $("btnRegister").disabled = true; msg.textContent = "กำลังบันทึก…";
  try {
    await runTransaction(db, async (tx) => {
      const idRef = doc(db, "studentIds", sid);
      if ((await tx.get(idRef)).exists()) throw new Error("SID_TAKEN");
      const profile = { uid, email, role, studentId: sid, name, createdAt: serverTimestamp() };
      tx.set(idRef, { uid, createdAt: serverTimestamp() });
      tx.set(doc(db, "users", uid), profile);
      if (role === "senior") tx.set(doc(db, "seniorProfiles", uid), { uid, studentId: sid, name, photo: S.regPhoto || "", updatedAt: serverTimestamp() });
    });
    S.profile = { uid, email, role, studentId: sid, name };
    S.view = role; msg.textContent = "";
    toast("ลงทะเบียนสำเร็จ 🎉");
    initSession();
  } catch (e) {
    msg.textContent = e.message === "SID_TAKEN" ? "รหัสนิสิตนี้ถูกลงทะเบียนแล้ว หากไม่ใช่คุณกรุณาติดต่อ Admin" : errText(e);
  } finally { $("btnRegister").disabled = false; }
};

/* ---------------- junior ---------------- */
function renderJunior() {
  const p = S.profile; if (p?.role !== "junior") return;
  $("juniorWelcome").textContent = `Junior · ${p.studentId} · ${p.name}`;

  if (S.clue) {
    $("clueList").innerHTML = S.clue.clues?.length
      ? S.clue.clues.map((c, i) => `<div class="clue"><b>คำใบ้ ${i + 1}</b>${esc(c)}</div>`).join("")
      : '<div class="notice">ยังไม่มีคำใบ้สำหรับรหัสนิสิตนี้ คุณยังสามารถเลือก Senior ได้</div>';
  }

  const r = S.myRequest, matched = r?.matchedSeniorUid;
  $("pickCount").textContent = `เลือกแล้ว ${S.draft.length}/${MAX}`;
  const st = $("juniorStatus");
  if (matched) {
    const s = S.seniors[matched];
    st.className = "notice success";
    st.innerHTML = `🎉 Match สำเร็จกับ <b>${esc(s?.name || r.matchedSeniorName || matched)}</b>${s ? ` (รหัส ${esc(s.studentId)})` : ""}`;
  } else if (S.dirty) {
    st.className = "notice"; st.textContent = "มีการเปลี่ยนแปลงที่ยังไม่ได้ยืนยัน — กด “ยืนยันการเลือก” เพื่อส่งคำขอ";
  } else if (r?.submitted) {
    st.className = "notice"; st.textContent = "ส่งตัวเลือกแล้ว รอ Senior ตอบรับ ⏳";
  } else st.className = "notice hidden";
  show("juniorActions", !matched);

  const list = Object.values(S.seniors).sort((a, b) => a.name.localeCompare(b.name, "th"));
  const missing = S.draft.filter((id) => !S.seniors[id]);
  $("seniorOptions").innerHTML = (list.length
    ? list.map((s) => {
        const on = S.draft.includes(s.uid), isMatch = matched === s.uid;
        const btn = matched
          ? (isMatch ? '<span class="badge green">✓ Matched</span>' : "")
          : `<button class="${on ? "primary" : "secondary"}" data-pick="${esc(s.uid)}">${on ? "✓ เลือกแล้ว" : "เลือก"}</button>`;
        return `<div class="senior-card ${on || isMatch ? "selected" : ""}"><div class="avatar">${avatarHtml(s.photo)}</div>
          <div class="info"><h3>${esc(s.name)}</h3><p>รหัสนิสิต ${esc(s.studentId)}</p></div>${btn}</div>`;
      }).join("")
    : '<div class="empty">ยังไม่มี Senior ลงทะเบียน</div>')
    + missing.map((id) => `<div class="senior-card"><div class="info"><p>Senior ที่คุณเลือกไว้ถูกลบออกจากระบบแล้ว</p></div><button class="secondary sm" data-pick="${esc(id)}">นำออก</button></div>`).join("");
}

$("seniorOptions").onclick = (e) => {
  const id = e.target.closest("[data-pick]")?.dataset.pick;
  if (!id || S.myRequest?.matchedSeniorUid) return;
  if (S.draft.includes(id)) S.draft = S.draft.filter((x) => x !== id);
  else if (S.draft.length < MAX) S.draft.push(id);
  else return toast(`เลือก Senior ได้สูงสุด ${MAX} คน`, true);
  S.dirty = true; renderJunior();
};

async function writeRequest(selected, submitted) {
  const p = S.profile;
  await setDoc(doc(db, "requests", S.user.uid), {
    juniorUid: S.user.uid, juniorStudentId: p.studentId, juniorName: p.name,
    selected, submitted, matchedSeniorUid: null, updatedAt: serverTimestamp()
  });
}
$("btnSubmitPicks").onclick = async () => {
  const sel = S.draft.filter((id) => S.seniors[id]);
  if (!sel.length) return toast("กรุณาเลือก Senior อย่างน้อย 1 คน", true);
  try { await writeRequest(sel, true); S.dirty = false; S.draft = sel; renderJunior(); toast("ส่งคำขอแล้ว! Senior จะเห็นคำขอทันที"); }
  catch (e) { onErr(e); }
};
$("btnClearPicks").onclick = async () => {
  try { await writeRequest([], false); S.dirty = false; S.draft = []; renderJunior(); toast("ล้างตัวเลือกแล้ว"); }
  catch (e) { onErr(e); }
};

/* ---------------- senior ---------------- */
function renderSenior() {
  const p = S.profile; if (p?.role !== "senior") return;
  const me = S.seniors[S.user.uid];
  if (me && !S.spPhoto) $("spPreview").innerHTML = avatarHtml(me.photo);

  let accepted = 0, waiting = 0;
  const rows = [...S.incoming].sort((a, b) => a.juniorStudentId.localeCompare(b.juniorStudentId)).map((r) => {
    const mine = r.matchedSeniorUid === S.user.uid, other = r.matchedSeniorUid && !mine;
    if (mine) accepted++; else if (!other) waiting++;
    const status = mine ? '<span class="badge green">✓ Matched</span>'
      : other ? '<span class="badge gray">Match กับ Senior คนอื่นแล้ว</span>'
      : `<button class="primary" data-accept="${esc(r.id)}">Match</button>`;
    return `<div class="senior-card"><div class="avatar">🎓</div><div class="info"><h3>${esc(r.juniorName || "Junior")}</h3>
      <p>รหัสนิสิต ${esc(r.juniorStudentId)} · ${mine ? "Match สำเร็จ" : other ? "ปิดคำขอ" : "รอการตอบรับ"}</p></div>${status}</div>`;
  });
  $("incomingCount").textContent = S.incoming.length;
  $("acceptedCount").textContent = accepted;
  $("remainingCount").textContent = waiting;
  $("seniorRequests").innerHTML = rows.join("") || '<div class="empty">ยังไม่มีคำขอจาก Junior</div>';
}

$("seniorRequests").onclick = async (e) => {
  const jid = e.target.closest("[data-accept]")?.dataset.accept; if (!jid) return;
  if (!confirm("ยืนยันการ Match กับ Junior คนนี้?")) return;
  const uid = S.user.uid;
  try {
    await runTransaction(db, async (tx) => {
      const ref = doc(db, "requests", jid), s = await tx.get(ref);
      if (!s.exists()) throw new Error("คำขอนี้ถูกยกเลิกแล้ว");
      const r = s.data();
      if (r.matchedSeniorUid) throw new Error("Junior คนนี้ Match กับ Senior คนอื่นแล้ว");
      if (!r.submitted || !r.selected?.includes(uid)) throw new Error("Junior เปลี่ยนตัวเลือกแล้ว");
      tx.update(ref, { matchedSeniorUid: uid, matchedSeniorName: S.profile.name, matchedAt: serverTimestamp() });
    });
    toast("ยืนยัน Match สำเร็จ 🎉");
  } catch (err) { toast(errText(err), true); }
};

$("spPhoto").onchange = async (e) => {
  const f = e.target.files?.[0]; if (!f) return;
  try { S.spPhoto = await resizeImage(f); $("spPreview").innerHTML = avatarHtml(S.spPhoto); }
  catch (err) { toast(err.message, true); e.target.value = ""; }
};
$("btnSaveSenior").onclick = async () => {
  const name = $("spName").value.trim(); if (!name) return ($("spMsg").textContent = "กรุณากรอกชื่อ");
  const uid = S.user.uid, cur = S.seniors[uid] || {};
  try {
    const b = writeBatch(db);
    b.update(doc(db, "users", uid), { name });
    b.set(doc(db, "seniorProfiles", uid), { uid, studentId: S.profile.studentId, name, photo: S.spPhoto || cur.photo || "", updatedAt: serverTimestamp() });
    await b.commit();
    S.profile.name = name; S.spPhoto = ""; $("spPhoto").value = "";
    $("spMsg").textContent = "บันทึกโปรไฟล์เรียบร้อย";
  } catch (e) { $("spMsg").textContent = errText(e); }
};

/* ---------------- admin ---------------- */
function renderAdmin() {
  if (!S.isAdmin) return;
  const { users, requests, admins } = S.ad;
  const juniors = users.filter((u) => u.role === "junior"), seniors = users.filter((u) => u.role === "senior");
  const submitted = requests.filter((r) => r.submitted), matched = requests.filter((r) => r.matchedSeniorUid);
  $("adSeniors").textContent = seniors.length;
  $("adJuniors").textContent = juniors.length;
  $("adSubmitted").textContent = submitted.length;
  $("adMatches").textContent = matched.length;
  $("adClues").textContent = S.ad.clues;

  const myEmail = S.user.email.toLowerCase();
  $("adminList").innerHTML = `<table>${admins.map((a) => `<tr><td>${esc(a)}</td><td style="text-align:right">${a === myEmail ? '<span class="small">คุณ</span>' : `<button class="danger sm" data-deladmin="${esc(a)}">ลบ</button>`}</td></tr>`).join("")}</table>`;

  const sName = (uid) => S.seniors[uid] ? `${esc(S.seniors[uid].name)} <span class="small">${esc(S.seniors[uid].studentId)}</span>` : `<span class="small">(ลบแล้ว)</span>`;
  const reqRows = [...submitted].sort((a, b) => a.juniorStudentId.localeCompare(b.juniorStudentId)).map((r) => `<tr>
      <td><b>${esc(r.juniorStudentId)}</b><br><span class="small">${esc(r.juniorName || "")}</span></td>
      <td>${(r.selected || []).map(sName).join("<br>")}</td>
      <td>${r.matchedSeniorUid ? `<span class="badge green">✓ ${sName(r.matchedSeniorUid)}</span>` : '<span class="badge orange">รอตอบรับ</span>'}</td>
      <td style="text-align:right">${r.matchedSeniorUid ? `<button class="danger sm" data-unmatch="${esc(r.id)}">ยกเลิก Match</button>` : ""}</td></tr>`);
  $("matchTable").innerHTML = reqRows.length
    ? `<table><tr><th>Junior</th><th>เลือก Senior</th><th>สถานะ</th><th></th></tr>${reqRows.join("")}</table>`
    : '<div class="empty">ยังไม่มีคำขอ</div>';

  const f = $("userFilter").value.trim().toLowerCase();
  const incomingCount = (uid) => submitted.filter((r) => r.selected?.includes(uid)).length;
  const reqOf = Object.fromEntries(requests.map((r) => [r.id, r]));
  const uRows = [...users].filter((u) => !f || [u.studentId, u.name, u.email].some((x) => String(x).toLowerCase().includes(f)))
    .sort((a, b) => (a.role + a.studentId).localeCompare(b.role + b.studentId))
    .map((u) => {
      const info = u.role === "senior" ? `ถูกเลือก ${incomingCount(u.uid)} ครั้ง`
        : reqOf[u.uid]?.matchedSeniorUid ? "Match แล้ว" : reqOf[u.uid]?.submitted ? "ส่งคำขอแล้ว" : "ยังไม่ส่งคำขอ";
      return `<tr><td><span class="badge ${u.role === "senior" ? "" : "gray"}">${u.role}</span></td><td><b>${esc(u.studentId)}</b></td>
        <td>${esc(u.name)}</td><td class="small">${esc(u.email)}</td><td class="small">${info}</td>
        <td style="text-align:right"><button class="danger sm" data-deluser="${esc(u.uid)}">ลบ</button></td></tr>`;
    });
  $("userTable").innerHTML = uRows.length
    ? `<table><tr><th>บทบาท</th><th>รหัส</th><th>ชื่อ</th><th>อีเมล</th><th>สถานะ</th><th></th></tr>${uRows.join("")}</table>`
    : '<div class="empty">ไม่พบผู้ใช้</div>';
}
$("userFilter").oninput = renderAdmin;

$("adminView").onclick = async (e) => {
  const t = e.target.closest("button"); if (!t) return;
  try {
    if (t.dataset.unmatch) {
      if (!confirm("ยกเลิก Match นี้? Junior จะกลับไปสถานะรอตอบรับ")) return;
      await updateDoc(doc(db, "requests", t.dataset.unmatch), { matchedSeniorUid: null, matchedSeniorName: deleteField(), matchedAt: deleteField() });
      toast("ยกเลิก Match แล้ว");
    } else if (t.dataset.deluser) {
      const u = S.ad.users.find((x) => x.uid === t.dataset.deluser); if (!u) return;
      if (!confirm(`ลบผู้ใช้ ${u.studentId} (${u.name})?\nข้อมูลโปรไฟล์และคำขอของผู้ใช้นี้จะถูกลบ`)) return;
      const b = writeBatch(db);
      b.delete(doc(db, "users", u.uid));
      b.delete(doc(db, "studentIds", u.studentId));
      b.delete(doc(db, "seniorProfiles", u.uid));
      b.delete(doc(db, "requests", u.uid));
      await b.commit(); toast("ลบผู้ใช้แล้ว");
    } else if (t.dataset.deladmin) {
      if (!confirm(`ลบสิทธิ์ Admin ของ ${t.dataset.deladmin}?`)) return;
      await writeBatch(db).delete(doc(db, "admins", t.dataset.deladmin)).commit(); toast("ลบ Admin แล้ว");
    }
  } catch (err) { onErr(err); }
};

$("btnAddAdmin").onclick = async () => {
  const em = $("newAdmin").value.trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) return toast("อีเมลไม่ถูกต้อง", true);
  try { await setDoc(doc(db, "admins", em), { addedBy: S.user.email.toLowerCase(), addedAt: serverTimestamp() }); $("newAdmin").value = ""; toast("เพิ่ม Admin แล้ว"); }
  catch (e) { onErr(e); }
};

async function importClues(items) {
  const clean = new Map();
  for (const it of items) {
    const id = String(it.id ?? "").trim();
    const clues = (it.clues || []).map((c) => String(c).trim()).filter(Boolean);
    if (SID_RE.test(id)) clean.set(id, [...(clean.get(id) || []), ...clues]);
  }
  const entries = [...clean.entries()];
  for (let i = 0; i < entries.length; i += 400) {
    const b = writeBatch(db);
    entries.slice(i, i + 400).forEach(([id, clues]) => b.set(doc(db, "clues", id), { clues: [...new Set(clues)], updatedAt: serverTimestamp() }));
    await b.commit();
  }
  return entries.length;
}
function parseCSV(text) {
  const rows = []; let row = [], cur = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; }
    else if (c === '"') q = true;
    else if (c === ",") { row.push(cur); cur = ""; }
    else if (c === "\n" || c === "\r") { if (c === "\r" && text[i + 1] === "\n") i++; row.push(cur); rows.push(row); row = []; cur = ""; }
    else cur += c;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  return rows.filter((r) => r.length && SID_RE.test(r[0].trim())).map((r) => ({ id: r[0].trim(), clues: r.slice(1) }));
}
$("btnImportDefault").onclick = async () => {
  if (!confirm("นำเข้าคำใบ้ตั้งต้นจาก data/clues.json? (รหัสที่มีอยู่แล้วจะถูกเขียนทับ)")) return;
  $("clueMsg").textContent = "กำลังนำเข้า…";
  try { const items = await (await fetch("data/clues.json", { cache: "no-store" })).json(); $("clueMsg").textContent = `นำเข้าแล้ว ${await importClues(items)} รหัส`; }
  catch (e) { $("clueMsg").textContent = errText(e); }
};
$("clueFile").onchange = async (e) => {
  const f = e.target.files?.[0]; if (!f) return;
  $("clueMsg").textContent = "กำลังนำเข้า…";
  try {
    const text = (await f.text()).replace(/^﻿/, "");
    const items = f.name.toLowerCase().endsWith(".json") ? JSON.parse(text) : parseCSV(text);
    $("clueMsg").textContent = `นำเข้าแล้ว ${await importClues(items)} รหัส`;
  } catch (err) { $("clueMsg").textContent = errText(err); }
  e.target.value = "";
};

$("btnExport").onclick = async () => {
  try {
    const out = { exportedAt: new Date().toISOString() };
    for (const c of ["users", "seniorProfiles", "requests", "clues", "admins"]) {
      out[c] = (await getDocs(collection(db, c))).docs.map((d) => ({ _id: d.id, ...d.data() }));
    }
    const blob = new Blob([JSON.stringify(out, (k, v) => (v && typeof v.toDate === "function" ? v.toDate().toISOString() : v), 2)], { type: "application/json" });
    const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: `senior-junior-match-${Date.now()}.json` });
    a.click(); URL.revokeObjectURL(a.href);
  } catch (e) { onErr(e); }
};

$("btnResetRequests").onclick = async () => {
  if (prompt('พิมพ์ RESET เพื่อลบคำขอและ Match ทั้งหมด (ผู้ใช้และโปรไฟล์ยังอยู่)') !== "RESET") return;
  try {
    const docs = (await getDocs(collection(db, "requests"))).docs;
    for (let i = 0; i < docs.length; i += 400) { const b = writeBatch(db); docs.slice(i, i + 400).forEach((d) => b.delete(d.ref)); await b.commit(); }
    toast(`ลบคำขอแล้ว ${docs.length} รายการ`);
  } catch (e) { onErr(e); }
};
