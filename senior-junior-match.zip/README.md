# Senior & Junior Match — Google SSO + Firebase + GitHub Pages

เว็บแอปจับคู่พี่รหัส–น้องรหัส แยกบทบาท **Junior / Senior / Admin** ใช้ **Google Sign-In** (Google Workspace หรือ Google Account) ผ่าน Firebase Authentication และเก็บข้อมูลใน **Cloud Firestore** เป็นฐานข้อมูลกลาง อัปเดตแบบเรียลไทม์ทุกเครื่อง โฮสต์หน้าเว็บฟรีบน **GitHub Pages** (ใช้ Firebase แผนฟรี Spark ได้ ไม่ต้องใช้ Firebase Storage)

## โครงสร้างไฟล์

```
index.html               หน้าเว็บหลัก (Login / ลงทะเบียน / Junior / Senior / Admin)
css/style.css            สไตล์ (คงดีไซน์เดิม)
js/firebase-config.js    ★ ต้องแก้: ค่า Firebase + ตั้งค่าโดเมน/จำนวนที่เลือกได้
js/app.js                ลอจิกทั้งหมด (Firebase Web SDK v10 ผ่าน CDN ไม่ต้อง build)
data/clues.json          คำใบ้ตั้งต้น 61 รหัส (ตัดรหัสซ้ำ 68540103 ออกแล้ว)
firestore.rules          ★ กฎความปลอดภัยของฐานข้อมูล (ต้อง Publish)
firebase.json            สำหรับ deploy rules ด้วย Firebase CLI (ไม่บังคับ)
.nojekyll                ให้ GitHub Pages เสิร์ฟไฟล์ตรง ๆ
```

## ภาพรวมการทำงาน

| บทบาท | ได้มาอย่างไร | ทำอะไรได้ |
|---|---|---|
| **Junior** | Login Google → ลงทะเบียนเลือก Junior + รหัสนิสิต | ดูคำใบ้ **เฉพาะของตัวเอง**, เลือก Senior ได้ไม่เกิน 2 คน, ยืนยันการเลือก, เห็นผล Match |
| **Senior** | Login Google → ลงทะเบียนเลือก Senior + รหัส + รูป | แก้โปรไฟล์, เห็นคำขอเฉพาะที่เลือกตัวเอง, กด Match (ใครกดก่อนได้ก่อน) |
| **Admin** | อีเมลอยู่ใน collection `admins` | ดูสถิติ/ทุกคำขอ, นำเข้าคำใบ้ (JSON/CSV), ยกเลิก Match, ลบผู้ใช้, เพิ่ม/ลบ Admin, Export JSON, รีเซ็ตคำขอ |

- 1 บัญชี Google ผูกได้ 1 รหัสนิสิต และ 1 รหัสนิสิตใช้ได้ 1 บัญชี (กันสวมรอย)
- บทบาทเลือกได้ครั้งเดียว หากผิดให้ Admin ลบผู้ใช้ แล้วลงทะเบียนใหม่
- Junior แต่ละคน Match ได้กับ Senior คนเดียว ระบบล็อกด้วย transaction + security rules
- รูปโปรไฟล์ถูกย่อเป็น 256×256 JPEG (~30 KB) เก็บใน Firestore จึงไม่ต้องเปิด Storage/แผน Blaze

---

## ขั้นตอนตั้งค่า

### 1) สร้างโปรเจกต์ Firebase
1. ไปที่ https://console.firebase.google.com → **Add project** → ตั้งชื่อ เช่น `senior-junior-match` (ปิด Google Analytics ได้)
2. หน้า Project Overview กดไอคอน **Web `</>`** → ตั้งชื่อแอป → **Register app** (ไม่ต้องติ๊ก Firebase Hosting)
3. คัดลอกค่า `firebaseConfig` ไปวางใน **`js/firebase-config.js`**

### 2) เปิด Google Sign-In
1. **Build → Authentication → Get started → Sign-in method → Google → Enable**
2. ใส่ *Project support email* → Save
3. **Authentication → Settings → Authorized domains → Add domain** ใส่ `<github-username>.github.io`
   (มี `localhost` อยู่แล้วสำหรับทดสอบในเครื่อง)

### 3) สร้าง Cloud Firestore (ฐานข้อมูลกลาง)
1. **Build → Firestore Database → Create database**
2. Location แนะนำ `asia-southeast1 (Singapore)` (เปลี่ยนภายหลังไม่ได้)
3. เลือก **Start in production mode**
4. แท็บ **Rules** → ลบของเดิม วางเนื้อหาทั้งไฟล์ **`firestore.rules`** → **Publish**

### 4) ตั้ง Admin คนแรก
Firestore → **Data → Start collection**
- Collection ID: `admins`
- Document ID: อีเมล Google ของคุณ **ตัวพิมพ์เล็กทั้งหมด** เช่น `sataporn@dit.daikin.co.jp`
- เพิ่ม field อะไรก็ได้ 1 ตัว เช่น `role` (string) = `admin` → Save

Admin คนต่อไปเพิ่มได้จากหน้า Admin ในเว็บ

### 5) เผยแพร่บน GitHub Pages
1. สร้าง repository ใหม่ (Public หรือ Private ที่มี GitHub Pages) เช่น `senior-junior-match`
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ไว้ที่ **root** ของ branch `main`
   ```bash
   git init && git add . && git commit -m "Senior & Junior Match"
   git branch -M main
   git remote add origin https://github.com/<github-username>/senior-junior-match.git
   git push -u origin main
   ```
3. Repo → **Settings → Pages → Source: Deploy from a branch → Branch: `main` / `(root)` → Save**
4. รอ 1–2 นาที เว็บจะอยู่ที่ `https://<github-username>.github.io/senior-junior-match/`

> ทดสอบในเครื่องก่อนได้: `python3 -m http.server 8000` แล้วเปิด http://localhost:8000 (ต้องเปิดผ่าน http ไม่ใช่ดับเบิลคลิกไฟล์)

### 6) นำเข้าคำใบ้
Login ด้วยบัญชี Admin → แท็บ **⚙️ Admin** → **นำเข้าคำใบ้ตั้งต้น** (จาก `data/clues.json`)
หรือ **อัปโหลดไฟล์** CSV/JSON รุ่นใหม่:
```csv
studentId,clue1,clue2
68540001,พี่มีฟาร์มผม,
68540033,พั้นรักแมวแต่พี่รักหมา 🐶,155
```
(Export จาก Excel เป็น *CSV UTF-8* ได้เลย) — หลังนำเข้าแล้ว แนะนำให้ลบ `data/clues.json` ออกจาก repo หากไม่อยากให้คำใบ้เปิดสาธารณะ เพราะไฟล์บน GitHub Pages ใครก็เปิดอ่านได้

### 7) ทดสอบ flow
1. บัญชี A → ลงทะเบียน **Senior** + อัปโหลดรูป
2. บัญชี B → ลงทะเบียน **Junior** ด้วยรหัสที่มีคำใบ้ (เช่น 68540001) → เห็นคำใบ้ → เลือก A → **ยืนยันการเลือก**
3. บัญชี A → เห็นคำขอทันที → กด **Match** → บัญชี B เห็น “Match สำเร็จ”
4. Admin → เห็นสถิติและตาราง Match

---

## (แนะนำ) จำกัดเฉพาะ Google Workspace ของมหาวิทยาลัย/องค์กร
ต้องแก้ **2 ที่** ให้ตรงกัน:
1. `js/firebase-config.js` → `allowedDomain: "go.buu.ac.th"`
2. `firestore.rules` → ฟังก์ชัน `domainOk()`
   ```
   function domainOk() { return request.auth.token.email.matches('.*@go[.]buu[.]ac[.]th$'); }
   ```
   แล้ว Publish rules ใหม่ (ฝั่ง rules คือด่านจริง ฝั่งเว็บเป็นแค่ UX)

ถ้าเปลี่ยนจำนวนที่เลือกได้ (`maxPicks`) หรือรูปแบบรหัสนิสิต ให้แก้ `MAX_PICKS()` / `SID_REGEX()` ใน rules ให้ตรงกันเช่นกัน

## ความปลอดภัยเพิ่มเติม (ไม่บังคับ)
- **จำกัด API key**: Google Cloud Console → APIs & Services → Credentials → Browser key → Application restrictions: *Websites* ใส่ `https://<github-username>.github.io/*` และ `http://localhost:8000/*`
- **App Check (reCAPTCHA Enterprise)** เพื่อกันการเรียก API จากนอกเว็บ
- ค่าใน `firebase-config.js` เปิดเผยได้ตามปกติ — ข้อมูลถูกป้องกันด้วย `firestore.rules`

## Deploy rules ด้วย CLI (ทางเลือกแทนการวางใน Console)
```bash
npm i -g firebase-tools
firebase login
firebase use --add            # เลือกโปรเจกต์
firebase deploy --only firestore:rules
```

## โครงสร้างข้อมูล (Firestore)
| Collection | Doc ID | ฟิลด์หลัก | ใครอ่าน/เขียน |
|---|---|---|---|
| `admins` | อีเมล | – | Admin |
| `users` | uid | role, studentId, name, email | เจ้าของ (แก้ได้แค่ชื่อ), Admin |
| `studentIds` | รหัสนิสิต | uid | สร้างตอนลงทะเบียน, Admin ลบ |
| `seniorProfiles` | uid | studentId, name, photo | ผู้ใช้ที่ลงทะเบียนแล้วอ่านได้, Senior แก้ของตัวเอง |
| `clues` | รหัสนิสิต | clues[] | Junior อ่านของตัวเอง, Admin เขียน |
| `requests` | uid ของ Junior | selected[], submitted, matchedSeniorUid | Junior เขียนของตัวเอง, Senior ที่ถูกเลือกอ่าน/กด Match, Admin ทั้งหมด |

## แก้ปัญหาที่พบบ่อย
| อาการ | วิธีแก้ |
|---|---|
| `auth/unauthorized-domain` | เพิ่ม `<username>.github.io` ใน Authentication → Authorized domains |
| Pop-up Login ไม่ขึ้น | อนุญาต Pop-up ของเว็บ / ปิด in-app browser (เช่น เปิดลิงก์จาก LINE ให้เลือก “เปิดในเบราว์เซอร์”) |
| `permission-denied` / โหลดข้อมูลไม่สำเร็จ | ยังไม่ได้ Publish `firestore.rules` หรือบัญชีอยู่นอกโดเมนที่อนุญาต |
| ไม่เห็นแท็บ Admin | Document ID ใน `admins` ต้องเป็นอีเมลตัวพิมพ์เล็กตรงกับบัญชีที่ Login |
| ขึ้น “ยังไม่ได้ตั้งค่า Firebase” | ยังไม่ได้แก้ `js/firebase-config.js` |
| Junior ไม่เห็นคำใบ้ | Admin ยังไม่ได้นำเข้าคำใบ้ หรือรหัสนิสิตไม่มีในชุดข้อมูล |
